from app.clients.supla_client import SuplaClient
from app.security.oauth_state import oauth_state
from app.stores.settings_store import SettingsStore
from app.models.oauth import OAuthToken


class OAuthService:
    """Business logic for the SUPLA OAuth flow."""

    def __init__(
        self,
        store: SettingsStore | None = None,
    ) -> None:
        self._settings_store = (
            store if store is not None else SettingsStore()
        )

    def begin_authorization(self) -> str:
        """Build the SUPLA OAuth authorization URL."""

        settings = self._settings_store.load()

        state = oauth_state.generate()

        client = SuplaClient(
            server=settings.supla.server,
        )

        return client.build_authorize_url(
            state=state,
        )

    def exchange_code(
        self,
        code: str,
    ) -> OAuthToken:
        """Exchange an authorization code for OAuth tokens."""

        settings = self._settings_store.load()

        client = SuplaClient(
            server=settings.supla.server,
        )

        return client.exchange_code(
            code=code,
            client_id=settings.supla_client_id,
            client_secret=settings.supla_client_secret,
            redirect_uri=settings.supla_redirect_uri,
        )

    def complete_authorization(
        self,
        code: str,
        state: str,
    ) -> None:
        """Complete the OAuth authorization flow."""

        oauth_state.validate(state)

        settings = self._settings_store.load()

        client = SuplaClient(
            server=settings.supla.server,
        )

        token = client.exchange_code(
            code=code,
            client_id=settings.supla_client_id,
            client_secret=settings.supla_client_secret,
            redirect_uri=settings.supla_redirect_uri,
        )

        settings.supla.access_token = token.access_token
        settings.supla.refresh_token = token.refresh_token

        self._settings_store.save(settings)
