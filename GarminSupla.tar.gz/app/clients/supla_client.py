from urllib.parse import urlencode

import httpx

from app.config import settings
from app.models.oauth import OAuthToken


class SuplaClient:
    """HTTP client for the SUPLA API."""

    def __init__(
        self,
        server: str,
        client: httpx.Client | None = None,
    ) -> None:
        self._server = server.rstrip("/")
        self._client = client or httpx.Client(timeout=10.0)

    def build_authorize_url(
        self,
        state: str,
    ) -> str:
        """Build the SUPLA OAuth authorization URL."""

        params = {
            "client_id": settings.supla_client_id,
            "redirect_uri": settings.supla_redirect_uri,
            "response_type": "code",
            "state": state,
        }

        return f"{self._url('/oauth/v2/auth')}?{urlencode(params)}"

    def exchange_code(
        self,
        code: str,
        client_id: str,
        client_secret: str,
        redirect_uri: str,
    ) -> OAuthToken:
        """Exchange an OAuth authorization code for OAuth tokens."""

        try:
            response = self._client.post(
                f"{self._server}/oauth/v2/token",
                json={
                    "grant_type": "authorization_code",
                    "client_id": settings.supla_client_id,
                    "client_secret": settings.supla_client_secret,
                    "redirect_uri": settings.supla_redirect_uri,
                    "code": code,
                },
            )

            response.raise_for_status()

            return OAuthToken.model_validate(response.json())

        except httpx.HTTPStatusError as exc:

            if exc.response.status_code in (401, 403):
                raise UnauthorizedError(
                    "SUPLA API rejected the request."
                ) from exc

            raise TokenExchangeError(
                "Failed to exchange authorization code."
            ) from exc

        except httpx.RequestError as exc:

            raise ApiError(
                "Unable to communicate with the SUPLA API."
            ) from exc
